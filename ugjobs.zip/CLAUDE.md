# KaziUG: project guide for Claude Code

Full-stack job board for Uganda with a single-admin back office. Read this file before every task.

## What this project is
- Public site: job listings with search and filters, job pages, category pages, newsletter subscription (double opt-in), visible social profiles.
- Back office at /admin: the only user is the admin. Manages jobs, categories, social profiles, newsletters, subscribers, SMTP settings, site settings, the admin account and the audit log.
- There is no visitor or company sign-up, and no user accounts beyond the single admin.
- The original front-end prototype is in `prototype/` (reference only, do not copy it wholesale). Reuse its design and behaviour, and move data and logic to the server.

## Stack (fixed, do not change without asking)
- PHP 8.2+, vanilla, no web framework (no Laravel, Symfony framework, Slim, etc.).
- MySQL 8.0+ / MariaDB 10.6+ through PDO (mysql). Always use prepared statements. SQL must run on both (tests pass on MySQL 8.0 and MariaDB 10.6).
- Composer only for autoloading and these libraries: phpmailer/phpmailer, vlucas/phpdotenv, phpunit/phpunit (dev). Ask before adding any other package.
- Hosting: cPanel shared hosting (Apache). Web root is `public/` (`public/.htaccess` routes to the front controller; the root `.htaccess` forwards into `public/` if the document root can't be changed). All config comes from `.env`.
- Server-rendered PHP templates. Vanilla JS only, for progressive enhancement.
- Newsletters are sent by the app itself through the admin-configured SMTP. No external email service.

## Architecture
- Front controller: `public/index.php`. Everything else lives outside the web root.
- `src/Core`: router, request, response, session, CSRF, container, view renderer, DB connection, middleware pipeline.
- `src/Controllers`: thin. Validate input, call one service, return a response. No SQL, no business rules.
- `src/Services`: business logic (JobService, CategoryService, NewsletterService, SubscriberService, MailService, SettingsService, AuthService, AuditService).
- `src/Repositories`: all SQL, one repository per aggregate, each implementing an interface.
- `src/Validation`, `src/Middleware` (auth, CSRF, rate limit, security headers).
- `views/public`, `views/admin`, plus shared partials. Templates escape output through the shared helper. No logic beyond display.
- `database/migrations` (numbered MySQL SQL, run one statement at a time), `database/seeds`.
- `bin/console`: migrate, seed, admin:create, newsletter:work, analytics:rollup, config:check.
- `storage/logs`, `storage/uploads` (outside the web root). `tests/` for PHPUnit.

## SOLID rules
- Controllers depend on service interfaces. Services depend on repository interfaces. Never construct dependencies inside a class; use the container.
- One responsibility per class. If a class needs a "and" in its description, split it.
- Mail sending goes through `MailerInterface`. Never call PHPMailer from services or controllers directly.
- Add new behaviour by adding classes, not by editing existing senders or handlers, where practical.

## Security rules (non-negotiable)
- There must be no public registration, sign-up, or user-creation route. The admin is created only with `bin/console admin:create`, which refuses to create a second admin. A unique constraint enforces this in the database.
- Hash passwords with `password_hash` (argon2id if available). Never log passwords, tokens or SMTP credentials.
- CSRF token on every state-changing request, including AJAX.
- Session: regenerate the ID on login, Secure + HttpOnly + SameSite cookies, idle timeout.
- Rate-limit login (by IP and by email) with progressive lockout. Rate-limit the public subscribe form.
- Encrypt the SMTP password at rest with libsodium, using a key derived from `APP_KEY`. Never show it back after saving; show a masked placeholder.
- Sanitise admin-authored newsletter HTML with an allowlist. Never output raw HTML from the database except through that sanitiser.
- Subscription tokens: generate random values, store only a hash of confirmation tokens.
- Log every admin action to `audit_logs` (actor, action, entity, entity id, IP, time).
- Production error pages must not show stack traces.

## Database conventions
- Table and column names: snake_case, plural table names.
- Every migration has a matching rollback note at the top. MySQL commits DDL immediately, so migrations are not transactional: the Migrator runs each statement separately and records the file only after all succeed. Keep migrations small and re-runnable where possible.
- Soft-delete jobs with `deleted_at`. Other deletions are hard deletes unless the table has audit requirements.
- Status values are enforced with CHECK constraints. Job statuses: draft, published, closed, archived. Job status changes are recorded in `job_status_history`.
- Add an index for every foreign key and every column used in a WHERE or ORDER BY on a large table.
- Store timestamps as `DATETIME(6)` in UTC (the connection uses time_zone '+00:00'). Convert at the boundary with `Core/Database/DbTime` (`toDb()`/`fromDb()`); never bind `DATE_ATOM` strings, MariaDB rejects offsets.
- Lists are `JSON` columns; booleans are `TINYINT(1)` (compare with `= 1`); quote the reserved column name `` `key` ``.
- No `RETURNING`: use `Database::insert()` (returns the AUTO_INCREMENT id) and re-read the row.

## Public site rules
- Only published jobs that have not expired appear publicly.
- Search uses InnoDB FULLTEXT (boolean mode) over `jobs.search_text`, built by `Repositories/FullTextQuery` (prefixes, light stemming, stopwords dropped, REGEXP fallback for words under 3 letters).
- Every newsletter email includes a working unsubscribe link and the physical address from site settings.
- Job pages include meta tags and JSON-LD JobPosting markup.
- Analytics is first-party and cookieless: no third-party scripts, no email open/click tracking. Never store IP addresses, user agents or full referrer URLs in `analytics_events`. Raw events are kept 1 year (`AnalyticsRollup::RETENTION_DAYS`), daily totals after that. Update the Privacy and Cookie policies before collecting anything new.

## Back office rules
- Status changes follow: draft → published → closed → archived. Archiving does not delete. Show the status history.
- Deleting a category that still has jobs must either be blocked or reassign those jobs. Follow the decision recorded in the README.
- Newsletter sending never runs inside the web request. Sends are queued as `newsletter_deliveries` rows and processed by `bin/console newsletter:work`, which is run by a scheduler once a minute. Respect the per-minute rate limit, and retry failed sends up to 3 times with backoff.
- Subscriber import and export are CSV only, validated row by row.

## Commands
```
docker compose up -d                  # MySQL 8.0 on 3316 (kaziug + kaziug_test) and Mailpit (SMTP 1025, UI 8025)
composer install
cp .env.example .env                  # then fill in values
php bin/console config:check
php bin/console migrate
php bin/console seed                  # sample data, only when requested
php bin/console admin:create
php -S localhost:8000 -t public public/index.php   # local server (router script needed for paths with dots)
php bin/console newsletter:work       # one batch; run by cPanel cron every minute (--loop only on a VPS)
php bin/console analytics:rollup      # daily analytics totals + 1-year raw-event purge (schedule nightly; also runs on analytics page loads)
vendor/bin/phpunit
```

## Where things are wired
- Interface → implementation bindings: `config/container.php`. Routes: `config/routes.php`. Console commands: `config/commands.php`. Seeders: `config/seeders.php`.
- Global middleware order is set in `config/container.php` (Kernel factory). Public pages run `SharePublicData`; `/admin` runs `IdleTimeout` + `Authenticate`.
- Tests: `tests/Support/HttpTestCase` drives the real kernel; email goes to `RecordingTransportFactory` (`$this->mail`). Fakes for unit tests live in `tests/Support/Fakes`.
- Recorded design decisions (category delete blocked, import consent, etc.) are in README section 10.
If a command here does not exist yet, create it and update this section.

## Code style
- `declare(strict_types=1);` in every PHP file. PSR-12 formatting. PSR-4 namespaces under `App\`.
- Type every parameter, return value and property.
- Prefer small, named methods. No logic inside templates.
- Comments explain why, not what. No commented-out code.
- Use English for code, identifiers and UI text. Currency is UGX unless a field says otherwise.

## Workflow
- For any non-trivial task, first write a short plan and wait for approval.
- Build in stages. After each stage, confirm it works and write a short progress note: what changed, what is tested, what is open.
- Add or update tests for each service you change. Run `vendor/bin/phpunit` before reporting a task done.
- Do not add features outside the agreed scope. If a requirement is ambiguous, ask instead of guessing.
- Do not change the stack, the hosting target or the security rules without asking.
- Never commit `.env`, uploads, logs or credentials. Keep `.env.example` current.

## Things to avoid
- Adding a web framework, ORM or external email/marketing service.
- Adding any route that creates a user other than the admin.
- Building SQL strings with concatenated input.
- Putting business logic in controllers, views or migrations.
- Exposing SMTP passwords, tokens or stack traces in any response.
## Local environment notes
- On this machine the `php` on PATH is Herd Lite (static build, no pdo_mysql/sodium). Use the full Herd binary: `~/.config/herd/bin/php83/php.exe` (and `~/.config/herd/bin/composer.phar` through it).
- Tests use the `kaziug_test` database (`DB_TEST_DATABASE`); phpunit.xml forces `APP_ENV=testing`, and the test base class refuses any database not ending in `_test`.
- To run the suite on MariaDB too: `docker run -d --rm --name kz-maria-test -p 3317:3306 -e MARIADB_ROOT_PASSWORD=x -e MARIADB_DATABASE=kaziug_test -e MARIADB_USER=kaziug -e MARIADB_PASSWORD=kaziug mariadb:10.6`, then `DB_PORT=3317 vendor/bin/phpunit`.
- The old PostgreSQL data is still in the Docker volume `ugjobs_db-data` (not used by compose any more).
