--
-- PostgreSQL database dump
--

\restrict 2AgQ63HPlz22n0sVPmJoRg4HcnD3kO5Y9BHg3HJGcfrANOX5PSEvAYrxfV3sviC

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: jobs_search_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jobs_search_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search :=
        setweight(to_tsvector('english', coalesce(NEW.title, '')), 'A') ||
        setweight(to_tsvector('english', array_to_string(coalesce(NEW.skills, '{}'), ' ')), 'B') ||
        setweight(to_tsvector('english', coalesce(NEW.company, '')), 'B') ||
        setweight(to_tsvector('english', coalesce(NEW.summary, '')), 'C');
    RETURN NEW;
END
$$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users (
    id bigint NOT NULL,
    singleton boolean DEFAULT true NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    session_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT admin_users_email_lower_chk CHECK ((email = lower(email))),
    CONSTRAINT admin_users_singleton_chk CHECK (singleton)
);


--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.admin_users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.admin_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: analytics_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_daily (
    day date NOT NULL,
    dimension text NOT NULL,
    key text NOT NULL,
    pageviews integer DEFAULT 0 NOT NULL,
    visitors integer DEFAULT 0 NOT NULL,
    applies integer DEFAULT 0 NOT NULL,
    searches integer DEFAULT 0 NOT NULL,
    zero_results integer DEFAULT 0 NOT NULL,
    CONSTRAINT analytics_daily_applies_check CHECK ((applies >= 0)),
    CONSTRAINT analytics_daily_dimension_check CHECK ((dimension = ANY (ARRAY['total'::text, 'path'::text, 'page_type'::text, 'job'::text, 'category'::text, 'referrer'::text, 'utm_source'::text, 'utm_campaign'::text, 'device'::text, 'search'::text, 'filter'::text, 'channel'::text]))),
    CONSTRAINT analytics_daily_key_check CHECK ((length(key) <= 300)),
    CONSTRAINT analytics_daily_pageviews_check CHECK ((pageviews >= 0)),
    CONSTRAINT analytics_daily_searches_check CHECK ((searches >= 0)),
    CONSTRAINT analytics_daily_visitors_check CHECK ((visitors >= 0)),
    CONSTRAINT analytics_daily_zero_results_check CHECK ((zero_results >= 0))
);


--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_events (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    type text NOT NULL,
    visitor_hash text NOT NULL,
    path text NOT NULL,
    page_type text NOT NULL,
    job_id bigint,
    category_id bigint,
    referrer_host text,
    utm_source text,
    utm_medium text,
    utm_campaign text,
    device text NOT NULL,
    apply_channel text,
    search_query text,
    search_filters text[] DEFAULT '{}'::text[] NOT NULL,
    result_count integer,
    CONSTRAINT analytics_events_apply_channel_check CHECK ((apply_channel = ANY (ARRAY['link'::text, 'email'::text]))),
    CONSTRAINT analytics_events_apply_channel_chk CHECK (((type = 'apply_click'::text) = (apply_channel IS NOT NULL))),
    CONSTRAINT analytics_events_device_check CHECK ((device = ANY (ARRAY['mobile'::text, 'tablet'::text, 'desktop'::text]))),
    CONSTRAINT analytics_events_page_type_check CHECK ((page_type = ANY (ARRAY['home'::text, 'category'::text, 'city'::text, 'job'::text, 'page'::text]))),
    CONSTRAINT analytics_events_path_check CHECK (((length(path) >= 1) AND (length(path) <= 300))),
    CONSTRAINT analytics_events_referrer_host_check CHECK (((length(referrer_host) >= 1) AND (length(referrer_host) <= 255))),
    CONSTRAINT analytics_events_result_count_check CHECK ((result_count >= 0)),
    CONSTRAINT analytics_events_search_query_check CHECK (((length(search_query) >= 1) AND (length(search_query) <= 100))),
    CONSTRAINT analytics_events_type_check CHECK ((type = ANY (ARRAY['pageview'::text, 'apply_click'::text]))),
    CONSTRAINT analytics_events_utm_campaign_check CHECK (((length(utm_campaign) >= 1) AND (length(utm_campaign) <= 100))),
    CONSTRAINT analytics_events_utm_medium_check CHECK (((length(utm_medium) >= 1) AND (length(utm_medium) <= 100))),
    CONSTRAINT analytics_events_utm_source_check CHECK (((length(utm_source) >= 1) AND (length(utm_source) <= 100))),
    CONSTRAINT analytics_events_visitor_hash_check CHECK ((visitor_hash ~ '^[a-f0-9]{32}$'::text))
);


--
-- Name: analytics_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.analytics_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.analytics_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: analytics_salts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_salts (
    day date NOT NULL,
    salt bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT analytics_salts_salt_check CHECK ((length(salt) = 32))
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    actor text NOT NULL,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip inet,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: job_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_categories (
    id bigint NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT job_categories_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 100))),
    CONSTRAINT job_categories_slug_check CHECK ((slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'::text))
);


--
-- Name: job_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.job_categories ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.job_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: job_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_status_history (
    id bigint NOT NULL,
    job_id bigint NOT NULL,
    from_status text,
    to_status text NOT NULL,
    changed_by bigint,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT job_status_history_from_status_check CHECK ((from_status = ANY (ARRAY['draft'::text, 'published'::text, 'closed'::text, 'archived'::text]))),
    CONSTRAINT job_status_history_to_status_check CHECK ((to_status = ANY (ARRAY['draft'::text, 'published'::text, 'closed'::text, 'archived'::text])))
);


--
-- Name: job_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.job_status_history ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.job_status_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    company text NOT NULL,
    location text NOT NULL,
    is_remote boolean DEFAULT false NOT NULL,
    job_type text NOT NULL,
    experience_level text NOT NULL,
    category_id bigint NOT NULL,
    salary_min bigint,
    salary_max bigint,
    currency character(3) DEFAULT 'UGX'::bpchar NOT NULL,
    summary text NOT NULL,
    responsibilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    requirements jsonb DEFAULT '[]'::jsonb NOT NULL,
    skills text[] DEFAULT '{}'::text[] NOT NULL,
    apply_url text,
    apply_email text,
    status text DEFAULT 'draft'::text NOT NULL,
    published_at timestamp with time zone,
    expires_at timestamp with time zone,
    deleted_at timestamp with time zone,
    search tsvector,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    positions integer DEFAULT 1 NOT NULL,
    salary_scale text,
    application_instructions text,
    reports_to text,
    CONSTRAINT jobs_application_instructions_chk CHECK (((application_instructions IS NULL) OR ((length(btrim(application_instructions)) >= 1) AND (length(btrim(application_instructions)) <= 2000)))),
    CONSTRAINT jobs_apply_url_check CHECK (((apply_url IS NULL) OR (apply_url ~* '^https?://'::text))),
    CONSTRAINT jobs_company_check CHECK (((length(btrim(company)) >= 1) AND (length(btrim(company)) <= 200))),
    CONSTRAINT jobs_currency_check CHECK ((currency ~ '^[A-Z]{3}$'::text)),
    CONSTRAINT jobs_experience_level_check CHECK ((experience_level = ANY (ARRAY['entry'::text, 'mid'::text, 'senior'::text]))),
    CONSTRAINT jobs_job_type_check CHECK ((job_type = ANY (ARRAY['full-time'::text, 'part-time'::text, 'contract'::text, 'internship'::text]))),
    CONSTRAINT jobs_location_check CHECK (((length(btrim(location)) >= 1) AND (length(btrim(location)) <= 120))),
    CONSTRAINT jobs_positions_chk CHECK (((positions >= 1) AND (positions <= 10000))),
    CONSTRAINT jobs_published_at_chk CHECK (((status = 'draft'::text) OR (published_at IS NOT NULL))),
    CONSTRAINT jobs_reports_to_chk CHECK (((reports_to IS NULL) OR ((length(btrim(reports_to)) >= 1) AND (length(btrim(reports_to)) <= 150)))),
    CONSTRAINT jobs_requirements_check CHECK ((jsonb_typeof(requirements) = 'array'::text)),
    CONSTRAINT jobs_responsibilities_check CHECK ((jsonb_typeof(responsibilities) = 'array'::text)),
    CONSTRAINT jobs_salary_amount_or_scale_chk CHECK (((salary_scale IS NULL) OR ((salary_min IS NULL) AND (salary_max IS NULL)))),
    CONSTRAINT jobs_salary_max_check CHECK ((salary_max >= 0)),
    CONSTRAINT jobs_salary_min_check CHECK ((salary_min >= 0)),
    CONSTRAINT jobs_salary_range_chk CHECK (((salary_min IS NULL) OR (salary_max IS NULL) OR (salary_max >= salary_min))),
    CONSTRAINT jobs_salary_scale_chk CHECK (((salary_scale IS NULL) OR ((length(btrim(salary_scale)) >= 1) AND (length(btrim(salary_scale)) <= 30)))),
    CONSTRAINT jobs_slug_check CHECK ((slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'::text)),
    CONSTRAINT jobs_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'closed'::text, 'archived'::text]))),
    CONSTRAINT jobs_title_check CHECK (((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.jobs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    key text NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    window_started_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_attempts_failure_count_check CHECK ((failure_count >= 0))
);


--
-- Name: newsletter_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.newsletter_deliveries (
    id bigint NOT NULL,
    newsletter_id bigint NOT NULL,
    subscriber_id bigint NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT newsletter_deliveries_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT newsletter_deliveries_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'sent'::text, 'failed'::text])))
);


--
-- Name: newsletter_deliveries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.newsletter_deliveries ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.newsletter_deliveries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: newsletters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.newsletters (
    id bigint NOT NULL,
    subject text NOT NULL,
    preheader text DEFAULT ''::text NOT NULL,
    body_html text DEFAULT ''::text NOT NULL,
    body_text text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    scheduled_at timestamp with time zone,
    sent_at timestamp with time zone,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT newsletters_scheduled_chk CHECK (((status <> 'scheduled'::text) OR (scheduled_at IS NOT NULL))),
    CONSTRAINT newsletters_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'scheduled'::text, 'sending'::text, 'sent'::text, 'failed'::text]))),
    CONSTRAINT newsletters_subject_check CHECK (((length(btrim(subject)) >= 1) AND (length(btrim(subject)) <= 200)))
);


--
-- Name: newsletters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.newsletters ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.newsletters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    payload text NOT NULL,
    last_activity timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_assets (
    key text NOT NULL,
    mime_type text NOT NULL,
    content bytea NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT site_assets_mime_type_check CHECK ((mime_type = ANY (ARRAY['image/png'::text, 'image/jpeg'::text, 'image/webp'::text])))
);


--
-- Name: smtp_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smtp_settings (
    id smallint DEFAULT 1 NOT NULL,
    host text DEFAULT ''::text NOT NULL,
    port integer DEFAULT 587 NOT NULL,
    encryption text DEFAULT 'tls'::text NOT NULL,
    username text DEFAULT ''::text NOT NULL,
    password_encrypted text,
    from_name text DEFAULT ''::text NOT NULL,
    from_email text DEFAULT ''::text NOT NULL,
    reply_to text DEFAULT ''::text NOT NULL,
    last_tested_at timestamp with time zone,
    last_test_result text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT smtp_settings_encryption_check CHECK ((encryption = ANY (ARRAY['none'::text, 'tls'::text, 'ssl'::text]))),
    CONSTRAINT smtp_settings_id_check CHECK ((id = 1)),
    CONSTRAINT smtp_settings_port_check CHECK (((port >= 1) AND (port <= 65535)))
);


--
-- Name: social_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_profiles (
    id bigint NOT NULL,
    platform text NOT NULL,
    label text NOT NULL,
    url text NOT NULL,
    icon_key text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT social_profiles_icon_key_check CHECK ((icon_key = ANY (ARRAY['facebook'::text, 'x'::text, 'instagram'::text, 'linkedin'::text, 'youtube'::text, 'tiktok'::text, 'whatsapp'::text, 'telegram'::text, 'website'::text]))),
    CONSTRAINT social_profiles_label_check CHECK (((length(btrim(label)) >= 1) AND (length(btrim(label)) <= 100))),
    CONSTRAINT social_profiles_platform_check CHECK (((length(btrim(platform)) >= 1) AND (length(btrim(platform)) <= 60))),
    CONSTRAINT social_profiles_url_check CHECK ((url ~* '^https?://'::text))
);


--
-- Name: social_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.social_profiles ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.social_profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscribers (
    id bigint NOT NULL,
    email text NOT NULL,
    name text,
    status text DEFAULT 'pending'::text NOT NULL,
    consent_at timestamp with time zone,
    consent_ip inet,
    confirm_token_hash text,
    confirm_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone,
    unsubscribe_token text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    unsubscribed_at timestamp with time zone,
    CONSTRAINT subscribers_email_check CHECK (((length(email) >= 3) AND (length(email) <= 254))),
    CONSTRAINT subscribers_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'unsubscribed'::text, 'bounced'::text])))
);


--
-- Name: subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.subscribers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.subscribers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_users (id, singleton, email, password_hash, session_version, created_at, updated_at) FROM stdin;
6	t	admin@admin.com	$argon2id$v=19$m=65536,t=4,p=1$U0lGVzJncXJIem9wa1pIQg$3w4+9l4UjT/HNfWuvSomlUd1n60xJlUFqL+U8QHwvvQ	1	2026-10-20 10:45:06.849768+00	2026-10-20 10:45:06.849768+00
\.


--
-- Data for Name: analytics_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_daily (day, dimension, key, pageviews, visitors, applies, searches, zero_results) FROM stdin;
2026-10-27	category	16	9	1	3	5	2
2026-10-27	channel	link	0	0	3	0	0
2026-10-27	device	desktop	9	1	0	5	2
2026-10-27	filter	remote	2	1	0	2	2
2026-10-27	filter	type	5	1	0	5	2
2026-10-27	job	21	2	1	2	1	0
2026-10-27	job	27	1	1	1	0	0
2026-10-27	page_type	category	8	1	0	5	2
2026-10-27	page_type	job	1	1	0	0	0
2026-10-27	path	/categories/administration	8	1	0	5	2
2026-10-27	path	/jobs/receptionist-uganda-heart-institute	1	1	0	0	0
2026-10-27	total		9	1	3	5	2
\.


--
-- Data for Name: analytics_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_events (id, occurred_at, type, visitor_hash, path, page_type, job_id, category_id, referrer_host, utm_source, utm_medium, utm_campaign, device, apply_channel, search_query, search_filters, result_count) FROM stdin;
1	2026-10-27 08:40:48.27384+00	pageview	ad4374c25823348af2e46edef86753e9	/jobs/receptionist-uganda-heart-institute	job	27	16	\N	\N	\N	\N	desktop	\N	\N	{}	\N
2	2026-10-27 08:41:53.11053+00	apply_click	ad4374c25823348af2e46edef86753e9	/jobs/receptionist-uganda-heart-institute/apply/link	job	27	16	\N	\N	\N	\N	desktop	link	\N	{}	\N
3	2026-10-27 08:42:22.179224+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	\N	16	\N	\N	\N	\N	desktop	\N	\N	{}	\N
4	2026-10-27 08:42:33.436837+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	\N	16	\N	\N	\N	\N	desktop	\N	\N	{type}	4
5	2026-10-27 08:42:47.068419+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	\N	16	\N	\N	\N	\N	desktop	\N	\N	{type}	4
6	2026-10-27 08:42:54.873047+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	21	16	\N	\N	\N	\N	desktop	\N	\N	{type}	4
7	2026-10-27 08:42:57.48373+00	apply_click	ad4374c25823348af2e46edef86753e9	/jobs/laundry-officer-uganda-heart-institute/apply/link	job	21	16	\N	\N	\N	\N	desktop	link	\N	{}	\N
8	2026-10-27 08:45:18.272805+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	\N	16	\N	\N	\N	\N	desktop	\N	\N	{type,remote}	0
9	2026-10-27 08:45:20.822851+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	\N	16	\N	\N	\N	\N	desktop	\N	\N	{type,remote}	0
10	2026-10-27 08:45:49.503348+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	\N	16	\N	\N	\N	\N	desktop	\N	\N	{}	\N
11	2026-10-27 08:45:51.149631+00	pageview	ad4374c25823348af2e46edef86753e9	/categories/administration	category	21	16	\N	\N	\N	\N	desktop	\N	\N	{}	\N
12	2026-10-27 08:45:53.925417+00	apply_click	ad4374c25823348af2e46edef86753e9	/jobs/laundry-officer-uganda-heart-institute/apply/link	job	21	16	\N	\N	\N	\N	desktop	link	\N	{}	\N
\.


--
-- Data for Name: analytics_salts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_salts (day, salt, created_at) FROM stdin;
2026-10-27	\\xcd071efcacf65ed8473cd456afb7bdb5c27da3cd481b4e177beacdc362d35865	2026-10-27 08:40:48.244409+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor, action, entity, entity_id, metadata, ip, created_at) FROM stdin;
19	console	admin.created	admin_user	6	{"email": "admin@admin.com"}	\N	2026-10-20 10:45:06.853962+00
20	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-20 10:45:17.232475+00
21	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-20 11:52:59.532127+00
22	admin@admin.com	settings.updated	settings	\N	{"changed": ["whatsapp_number"]}	::1	2026-10-20 12:20:20.112182+00
23	admin@admin.com	settings.updated	settings	\N	{"changed": ["contact_email"]}	::1	2026-10-20 12:24:31.361844+00
24	admin@admin.com	job.updated	job	15	{"title": "Operations Manager"}	::1	2026-10-20 12:34:45.164035+00
25	admin@admin.com	job.updated	job	14	{"title": "Digital Marketing Intern"}	::1	2026-10-20 12:35:30.05771+00
26	admin@admin.com	auth.logout	admin_user	6	[]	::1	2026-10-20 13:01:35.1766+00
27	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-20 13:01:39.881556+00
28	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-20 16:43:52.855096+00
29	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-23 11:12:56.045124+00
30	admin@admin.com	social_profile.updated	social_profile	1	{"url": "https://www.facebook.com/kaziuganda", "platform": "Facebook"}	::1	2026-10-23 11:13:20.040367+00
31	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-25 06:50:31.809417+00
32	admin@admin.com	social_profile.updated	social_profile	3	{"url": "https://www.linkedin.com/company/kaziug/", "platform": "LinkedIn"}	::1	2026-10-25 06:50:50.479324+00
33	console	category.created	category	12	{"name": "Imaging & Diagnostics"}	\N	2026-10-25 07:00:25.843734+00
34	console	category.created	category	13	{"name": "Research & Training"}	\N	2026-10-25 07:00:25.900317+00
35	console	category.created	category	14	{"name": "Nursing"}	\N	2026-10-25 07:00:25.933184+00
36	console	category.created	category	15	{"name": "Public Health"}	\N	2026-10-25 07:00:25.974923+00
37	console	category.created	category	16	{"name": "Administration"}	\N	2026-10-25 07:00:26.004794+00
38	console	category.created	category	17	{"name": "Support Services"}	\N	2026-10-25 07:00:26.06924+00
39	console	category.created	category	18	{"name": "Supply Chain"}	\N	2026-10-25 07:00:26.105115+00
40	console	category.created	category	19	{"name": "Engineering & Maintenance"}	\N	2026-10-25 07:00:26.137584+00
41	console	category.created	category	20	{"name": "Legal"}	\N	2026-10-25 07:00:26.165936+00
42	console	category.created	category	21	{"name": "Security"}	\N	2026-10-25 07:00:26.215136+00
43	console	category.created	category	22	{"name": "Research"}	\N	2026-10-25 07:15:20.437389+00
44	console	category.created	category	23	{"name": "Engineering"}	\N	2026-10-25 07:16:25.918441+00
45	admin@admin.com	auth.login	admin_user	6	[]	::1	2026-10-27 08:08:42.024994+00
46	admin@admin.com	analytics.exported	analytics	\N	{"to": "2026-10-27", "from": "2026-10-21", "rows": 7, "table": "daily"}	::1	2026-10-27 08:31:36.624429+00
\.


--
-- Data for Name: job_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_categories (id, name, slug, description, sort_order, is_active, created_at, updated_at) FROM stdin;
2	Technology	technology		10	t	2026-10-20 09:41:31.520058+00	2026-10-20 09:41:31.520058+00
3	Finance	finance		20	t	2026-10-20 09:41:31.541427+00	2026-10-20 09:41:31.541427+00
4	Healthcare	healthcare		30	t	2026-10-20 09:41:31.555504+00	2026-10-20 09:41:31.555504+00
5	Sales & Marketing	sales-marketing		40	t	2026-10-20 09:41:31.569409+00	2026-10-20 09:41:31.569409+00
6	Agriculture	agriculture		50	t	2026-10-20 09:41:31.583424+00	2026-10-20 09:41:31.583424+00
7	Design	design		60	t	2026-10-20 09:41:31.597384+00	2026-10-20 09:41:31.597384+00
8	Hospitality	hospitality		70	t	2026-10-20 09:41:31.611431+00	2026-10-20 09:41:31.611431+00
9	Education	education		80	t	2026-10-20 09:41:31.62531+00	2026-10-20 09:41:31.62531+00
10	Customer Service	customer-service		90	t	2026-10-20 09:41:31.656396+00	2026-10-20 09:41:31.656396+00
11	Operations	operations		100	t	2026-10-20 09:41:31.669592+00	2026-10-20 09:41:31.669592+00
12	Imaging & Diagnostics	imaging-diagnostics		110	t	2026-10-25 07:00:25.843734+00	2026-10-25 07:00:25.843734+00
13	Research & Training	research-training		120	t	2026-10-25 07:00:25.900317+00	2026-10-25 07:00:25.900317+00
14	Nursing	nursing		130	t	2026-10-25 07:00:25.933184+00	2026-10-25 07:00:25.933184+00
15	Public Health	public-health		140	t	2026-10-25 07:00:25.974923+00	2026-10-25 07:00:25.974923+00
16	Administration	administration		150	t	2026-10-25 07:00:26.004794+00	2026-10-25 07:00:26.004794+00
17	Support Services	support-services		160	t	2026-10-25 07:00:26.06924+00	2026-10-25 07:00:26.06924+00
18	Supply Chain	supply-chain		170	t	2026-10-25 07:00:26.105115+00	2026-10-25 07:00:26.105115+00
19	Engineering & Maintenance	engineering-maintenance		180	t	2026-10-25 07:00:26.137584+00	2026-10-25 07:00:26.137584+00
20	Legal	legal		190	t	2026-10-25 07:00:26.165936+00	2026-10-25 07:00:26.165936+00
21	Security	security		200	t	2026-10-25 07:00:26.215136+00	2026-10-25 07:00:26.215136+00
22	Research	research		210	t	2026-10-25 07:15:20.437389+00	2026-10-25 07:15:20.437389+00
23	Engineering	engineering		220	t	2026-10-25 07:16:25.918441+00	2026-10-25 07:16:25.918441+00
\.


--
-- Data for Name: job_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_status_history (id, job_id, from_status, to_status, changed_by, changed_at) FROM stdin;
1	1	\N	published	\N	2026-10-25 07:30:04.146659+00
2	2	\N	published	\N	2026-10-25 07:30:04.168797+00
3	3	\N	published	\N	2026-10-25 07:30:04.180513+00
4	4	\N	published	\N	2026-10-25 07:30:04.190823+00
5	5	\N	published	\N	2026-10-25 07:30:04.214863+00
6	6	\N	published	\N	2026-10-25 07:30:04.242663+00
7	7	\N	published	\N	2026-10-25 07:30:04.293451+00
8	8	\N	published	\N	2026-10-25 07:30:04.34148+00
9	9	\N	published	\N	2026-10-25 07:30:04.357997+00
10	10	\N	published	\N	2026-10-25 07:30:04.365724+00
11	11	\N	published	\N	2026-10-25 07:30:04.373337+00
12	12	\N	published	\N	2026-10-25 07:30:04.380698+00
13	13	\N	published	\N	2026-10-25 07:30:04.388255+00
14	14	\N	published	\N	2026-10-25 07:30:04.395907+00
15	15	\N	published	\N	2026-10-25 07:30:04.403672+00
16	16	\N	published	\N	2026-10-25 07:30:04.410848+00
17	17	\N	published	\N	2026-10-25 07:30:04.417914+00
18	18	\N	published	\N	2026-10-25 07:30:04.425536+00
19	19	\N	published	\N	2026-10-25 07:30:04.432597+00
20	20	\N	published	\N	2026-10-25 07:30:04.43947+00
21	21	\N	published	\N	2026-10-25 07:30:04.446183+00
22	22	\N	published	\N	2026-10-25 07:30:04.454781+00
23	23	\N	published	\N	2026-10-25 07:30:04.461939+00
24	24	\N	published	\N	2026-10-25 07:30:04.469915+00
25	25	\N	published	\N	2026-10-25 07:30:04.477439+00
26	26	\N	published	\N	2026-10-25 07:30:04.484454+00
27	27	\N	published	\N	2026-10-25 07:30:04.491384+00
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, title, slug, company, location, is_remote, job_type, experience_level, category_id, salary_min, salary_max, currency, summary, responsibilities, requirements, skills, apply_url, apply_email, status, published_at, expires_at, deleted_at, search, created_at, updated_at, positions, salary_scale, application_instructions, reports_to) FROM stdin;
1	Associate Consultant – Adult Cardiology	associate-consultant-adult-cardiology-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To provide comprehensive specialist care to adult patients with cardiovascular conditions through accurate diagnosis, evidence-based management, treatment, and ongoing follow-up, with the aim of improving cardiovascular health outcomes and quality of life.	["Diagnose and treat cardiovascular adult conditions", "Implement patient care management plans", "Conduct ward rounds in the specialty area.", "Participate in training programmes for all health Professionals.", "Supervise medical officers, interns and trainees", "Identify procurement needs of the department for equipment, drugs and other logistics", "Prepare departmental workplans, budgets and reports", "Prepares duty rosters."]	["MB.Ch.B from a recognized University or Institution.", "Master of Medicine degree (Internal Medicine) or its equivalent from a recognized University/Institution.", "Fellowship training in Adult Cardiology or a Masters in Cardiology from a recognized institution.", "Should be registered with the Uganda Medical and Dental Practitioners Council", "Must possess a valid practicing license.", "Working experience of at least three (3) years at a Medical Officer level."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accur':20C 'adult':3A,14C 'aim':34C 'associ':1A 'base':24C 'cardiolog':4A 'cardiovascular':17C,37C 'care':12C 'comprehens':10C 'condit':18C 'consult':2A 'diagnosi':21C 'evid':23C 'evidence-bas':22C 'follow':30C 'follow-up':29C 'health':38C 'heart':6B 'improv':36C 'institut':7B 'life':43C 'manag':25C 'ongo':28C 'outcom':39C 'patient':15C 'provid':9C 'qualiti':41C 'specialist':11C 'treatment':26C 'uganda':5B	2026-10-25 07:30:04.146659+00	2026-10-25 07:30:04.146659+00	4	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Adult Cardiology
2	Medical Officer	medical-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	entry	4	\N	\N	UGX	To participate in the management of adult cardiovascular patients. The Medical Officers who will be appointed shall undergo fellowship program for specialisation in Cardiology during their time of service in UHI.	["Receive, clerk, admit and discharge patients.", "Develop patient treatment plans.", "Collect data for research.", "Initiate and carryout investigations.", "Update patient records.", "Guiding patients and caregivers on treatment plans.", "Participate in ward rounds and in the specialty area.", "Supervision of medical interns and trainees"]	["MB.Ch.B from a recognized University or Institution.", "Master of Science (MSc) in Medicine (Internal Medicine) or its equivalent from a recognized University/Institution.", "Should be registered with the Uganda Medical and Dental Practitioners Council", "Must possess a valid practicing license."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'adult':12C 'appoint':21C 'cardiolog':29C 'cardiovascular':13C 'fellowship':24C 'heart':4B 'institut':5B 'manag':10C 'medic':1A,16C 'offic':2A,17C 'particip':7C 'patient':14C 'program':25C 'servic':34C 'shall':22C 'specialis':27C 'time':32C 'uganda':3B 'uhi':36C 'undergo':23C	2026-10-25 07:30:04.168797+00	2026-10-25 07:30:04.168797+00	5	UHI 4 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Associate Consultant – Adult Cardiology
3	Associate Consultant – Paediatric Cardiology	associate-consultant-paediatric-cardiology-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To provide comprehensive specialist care for paediatrics with cardiovascular conditions through accurate diagnosis, treatment, and ongoing follow-up, with the aim of improving cardiovascular health outcomes and quality of life.	["Diagnose and treat cardiovascular conditions", "Implement patient care management plans", "Conduct ward rounds in the specialty area.", "Participate in training programmes for health Professionals in Paediatric Cardiology.", "Supervise medical officers, interns and trainees", "Identify procurement needs of the department for equipment, drugs and other logistics", "Participates in preparation of departmental work plans, budgets and reports.", "Prepare duty rosters."]	["MBChB or its equivalent from a recognized University/Institution", "A Master of Medicine degree in Paediatrics and Child Health or its equivalent from a recognized University/Institution.", "Fellowship in Paediatric Cardiology or a Masters in Paediatric Cardiology from a recognized Institution.", "Should be registered with the Uganda Medical and Dental Practitioners Council.", "Must possess a valid practicing license.", "Working experience of at least three (3) years at a Medical Officer level."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accur':19C 'aim':29C 'associ':1A 'cardiolog':4A 'cardiovascular':16C,32C 'care':12C 'comprehens':10C 'condit':17C 'consult':2A 'diagnosi':20C 'follow':25C 'follow-up':24C 'health':33C 'heart':6B 'improv':31C 'institut':7B 'life':38C 'ongo':23C 'outcom':34C 'paediatr':3A,14C 'provid':9C 'qualiti':36C 'specialist':11C 'treatment':21C 'uganda':5B	2026-10-25 07:30:04.180513+00	2026-10-25 07:30:04.180513+00	3	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Paediatric Cardiology
4	Associate Consultant – Adult Cardiovascular Surgery	associate-consultant-adult-cardiovascular-surgery-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To provide comprehensive specialist care to adult patients requiring cardiovascular surgical intervention through accurate assessment, diagnosis, perioperative management, surgical treatment, and postoperative follow-up, with the aim of achieving optimal patient outcomes.	["Diagnose and treat cardiovascular conditions and conduct cardiovascular surgeries", "Implement patient care management plans", "Conduct ward rounds and in the specialty area.", "Participate in training programmes for all health Professionals.", "Supervise medical officers, interns and trainees", "Identify procurement needs of the department for equipment, drugs and other logistics", "Prepare departmental work plans, budgets and reports.", "Prepares duty rosters.", "Conduct performance evaluation of subordinates, provide constructive feedback and identify opportunities for growth."]	["MBCh.B degree or its equivalent from a recognized University or Institution.", "Master of science (MSC) in Medicine in Surgery from a recognized University/Institution.", "Must be registered with the Uganda Medical and Dental Practitioners Council.", "Must have completed fellowship in cardiovascular surgery.", "Must possess a valid practicing license.", "Working experience of at least three (3) years at a Medical Officer level."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accur':22C 'achiev':38C 'adult':3A,15C 'aim':36C 'assess':23C 'associ':1A 'cardiovascular':4A,18C 'care':13C 'comprehens':11C 'consult':2A 'diagnosi':24C 'follow':32C 'follow-up':31C 'heart':7B 'institut':8B 'intervent':20C 'manag':26C 'optim':39C 'outcom':41C 'patient':16C,40C 'periop':25C 'postop':30C 'provid':10C 'requir':17C 'specialist':12C 'surgeri':5A 'surgic':19C,27C 'treatment':28C 'uganda':6B	2026-10-25 07:30:04.190823+00	2026-10-25 07:30:04.190823+00	2	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Adult Cardiac Surgery
5	Associate Consultant – Paediatric Cardiac Surgery	associate-consultant-paediatric-cardiac-surgery-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To diagnose and manage paediatric patients requiring cardiac surgery, ensuring timely and effective treatment and optimal patient outcomes.	["Diagnose and treat paediatric cardiovascular conditions and conduct cardiovascular surgeries", "Implement patient care management plans.", "Conduct ward rounds in the specialty area.", "Participate in training programmes for all health Professionals.", "Supervise medical officers, interns and trainees.", "Identify procurement needs of the department for equipment, drugs and other logistics.", "Prepares duty rosters."]	["MBCh.B degree or its equivalent from a recognized University or Institution.", "Master of Medicine degree in General Surgery from a recognized University/Institution.", "Applicants should be registered with the Uganda Medical and Dental Practitioners Council.", "Fellowship in cardiovascular surgery.", "Must possess a valid practicing license.", "Working experience of at least three (3) years as a Medical Officer."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'associ':1A 'cardiac':4A,16C 'consult':2A 'diagnos':10C 'effect':21C 'ensur':18C 'heart':7B 'institut':8B 'manag':12C 'optim':24C 'outcom':26C 'paediatr':3A,13C 'patient':14C,25C 'requir':15C 'surgeri':5A,17C 'time':19C 'treatment':22C 'uganda':6B	2026-10-25 07:30:04.214863+00	2026-10-25 07:30:04.214863+00	2	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Paediatric Cardiac Surgery
6	Associate Consultant – Cardiac Critical Care	associate-consultant-cardiac-critical-care-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To provide comprehensive specialist care in management of cardiac critical care patients with the aim of achieving optimal patient outcomes.	["Diagnose and manage cardiac conditions and complications", "Assist in planning and coordinating Continuing Professional Development in his/her area of specialty for Health professional at the Institute and the catchment area.", "Plan, co-ordinate and conduct operational research in his/her specialty.", "Manage national referral system for patients at a superspecialised level.", "To supervise and train Medical Officers, and other Health Professionals under him/her.", "Ensure that discipline and the ethical code of conduct are observed by the staff under him/her.", "Provide technical and professional advice in his/her area of specialty.", "Advice on the procurement of equipment, drugs and other logistics required for his/her specialty."]	["MBChB degree or its equivalent from a recognized University or Institution.", "Master of Medicine (Anaesthesia/ Surgery/ Internal Medicine) or its equivalent in the relevant specialty or its equivalent from a recognized University/Institution.", "Fellowship in cardiac intensive care Management (at least two years training).", "Should be registered with the Uganda Medical and Dental Practitioners Council", "Should be interested in research.", "Must possess a valid practicing license.", "Should have a good working experience of at least three (3) years as General practitioner."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'achiev':25C 'aim':23C 'associ':1A 'cardiac':3A,17C 'care':5A,13C,19C 'comprehens':11C 'consult':2A 'critic':4A,18C 'heart':7B 'institut':8B 'manag':15C 'optim':26C 'outcom':28C 'patient':20C,27C 'provid':10C 'specialist':12C 'uganda':6B	2026-10-25 07:30:04.242663+00	2026-10-25 07:30:04.242663+00	4	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Cardiac Critical Care
7	Associate Consultant – Cardiac Anaesthesia	associate-consultant-cardiac-anaesthesia-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To provide comprehensive perioperative anaesthetic care to patients undergoing cardiac procedures, including preoperative assessment, intraoperative anaesthetic management, and postoperative care, ensuring patient safety and optimal clinical outcomes.	["Implement patient care management plans", "Conduct ward rounds in the specialty area", "Participate in training programmes for all health professionals", "Supervise medical officers, interns and trainees.", "Identify procurement needs of the department for equipment, drugs and other logistics.", "Prepare departmental workplans, budgets and reports.", "Prepare duty rosters."]	["MB.CHB from a recognized University/Institution", "Master of Medicine degree in Anaesthesia or its equivalent from a recognized University/Institution.", "Fellowship or equivalent in Cardiac Anaesthesia.", "Should be registered with the Uganda Medical and Dental Practitioners Council.", "Must possess a valid practicing license.", "Should have a good working experience of at least three (3) years as General Anaesthesiologist."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'anaesthesia':4A 'anaesthet':12C,23C 'assess':21C 'associ':1A 'cardiac':3A,17C 'care':13C,27C 'clinic':33C 'comprehens':10C 'consult':2A 'ensur':28C 'heart':6B 'includ':19C 'institut':7B 'intraop':22C 'manag':24C 'optim':32C 'outcom':34C 'patient':15C,29C 'periop':11C 'postop':26C 'preoper':20C 'procedur':18C 'provid':9C 'safeti':30C 'uganda':5B 'undergo':16C	2026-10-25 07:30:04.293451+00	2026-10-25 07:30:04.293451+00	2	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Adult Cardiac Anaesthesia
8	Associate Consultant – Radiologist	associate-consultant-radiologist-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To provide specialist radiology services through the interpretation and reporting of diagnostic imaging studies, with a focus on cardiovascular and related conditions, supporting accurate diagnosis, treatment planning, and ongoing management of patients while ensuring high-quality, safe, and timely imaging services.	["To assist the Consultant and participate in ensuring efficient management of services in his/her specialty at the Institute.", "Work in conjunction with the Medical Imaging Technologists, Radiographers, Sonographers and other Allied health professionals to ensure efficient running of the imaging services as well as ensuring quality of the diagnostic tests.", "Lead case discussion sessions in the respective units of the Imaging Department.", "Oversee schedule for preventive equipment maintenance.", "Supervise and train Medical Officers, and other Health Professionals under him/her.", "Participate in training programs for all health Professionals under him/her.", "Train and supervise Intern Doctors.", "Participate in continuing Medical Education in his/her area of specialty for Health professional at the Institute and the catchment area of the Institute including outreaches.", "Plan and conduct operational research in his/her specialty.", "Participate in the management of referral system for patients at National level.", "Ensure that discipline and the ethical code of conduct are observed by the staff under him/her.", "Seek technical and professional advice in his/her area of specialty from the supervising consultant or Institution.", "Advise on the procurement of equipment, drugs and other logistics required for his/her specialty"]	["MB.Ch.B degree or its equivalent from a recognized University or Institution.", "Master of Science (MSc) in Medicine (Radiology) or its equivalent in the relevant specialty, from a recognized University or Institution.", "Should be registered with the Uganda Medical and Dental Practitioners Council.", "Must possess a valid practicing license.", "Evidence of research will be an added advantage.", "Should have served as a Medical Officer for at least three (3) years."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accur':30C 'associ':1A 'cardiovascular':25C 'condit':28C 'consult':2A 'diagnosi':31C 'diagnost':18C 'ensur':40C 'focus':23C 'heart':5B 'high':42C 'high-qual':41C 'imag':19C,47C 'institut':6B 'interpret':14C 'manag':36C 'ongo':35C 'patient':38C 'plan':33C 'provid':8C 'qualiti':43C 'radiolog':10C 'radiologist':3A 'relat':27C 'report':16C 'safe':44C 'servic':11C,48C 'specialist':9C 'studi':20C 'support':29C 'time':46C 'treatment':32C 'uganda':4B	2026-10-25 07:30:04.34148+00	2026-10-25 07:30:04.34148+00	1	UHI 2 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Consultant – Radiologist
9	Radiographer	radiographer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	4	\N	\N	UGX	To provide safe, accurate, and timely diagnostic imaging services by performing radiographic examinations in accordance with established clinical protocols.	["Receive Patients and analyze their X-ray requests.", "Prepare X-ray equipment according to requests.", "Liaise with ward management in the preparation of Patients or X-rays.", "Take x-ray pictures, process X-ray films and prepare reports for the Doctor/ Clinical Officer.", "Maintain X-ray equipment."]	["Must have a Diploma in Medical Radiology from a recognized Institution.", "Must be registered with the Allied Health Professionals Council."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accord':19C 'accur':8C 'clinic':22C 'diagnost':11C 'establish':21C 'examin':17C 'heart':3B 'imag':12C 'institut':4B 'perform':15C 'protocol':23C 'provid':6C 'radiograph':1A,16C 'safe':7C 'servic':13C 'time':10C 'uganda':2B	2026-10-25 07:30:04.357997+00	2026-10-25 07:30:04.357997+00	1	UHI 5 MED 2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Radiographer
10	Medical Laboratory Technician	medical-laboratory-technician-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	4	\N	\N	UGX	To conduct laboratory investigations and ensure accurate, timely, and reliable laboratory results to support the diagnosis, treatment, and management of patients.	["Record and manage patient data and results", "Records management & Phlebotomy at the OPD and wards", "Perform laboratory investigations & submit reports to wards and out patients’ reception", "Prepare specimens & reagents according to established procedures.", "Service and maintain laboratory equipment to ensure good functionality.", "Maintain an inventory of the laboratory equipment.", "Manage inventory of blood and blood products", "Make reports and accountability of resources allocated", "Maintain the general cleanliness of the working environment safe", "Apply quality assurance for laboratory tests."]	["A Diploma in Medical Laboratory Technology/Techniques or its equivalent from a recognized University/Institution", "A certificate of Good Laboratory Practice [GLP] from a recognized institution", "Must be registered with Allied Health Professionals Council and holds a valid practicing license", "Must have an experience of at least 1 (one) year in a reputable healthcare facility."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accur':13C 'conduct':8C 'diagnosi':22C 'ensur':12C 'heart':5B 'institut':6B 'investig':10C 'laboratori':2A,9C,17C 'manag':25C 'medic':1A 'patient':27C 'reliabl':16C 'result':18C 'support':20C 'technician':3A 'time':14C 'treatment':23C 'uganda':4B	2026-10-25 07:30:04.365724+00	2026-10-25 07:30:04.365724+00	2	UHI 5 MED 2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Medical Laboratory Technologist
11	Senior Medical Research Officer	senior-medical-research-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	22	\N	\N	UGX	Arrange research commissioning and grant management processes to support the delivery and dissemination of research and maintain accurate research documentation and contribute to the monitoring of adherence to clinical research standards within the research team.	["Support the design, delivery and management of research commissions by working closely with the relevant Research team", "Work as a member of a team to design and continuously improve high-quality processes across the research portfolio.", "Work with the team to disseminate research", "Support the development and delivery of research programmes, including developing timelines; planning and monitoring progress and budgets", "Coordinate inputs from across the team and the wider organisation", "Identify and highlight risks and potential mitigations measures in the research processes.", "Work with the communication team to promote smooth flow of high quality internal and external communications around research programmes and projects.", "Participate in the development of application and selection materials and processes for award holders", "Managing selection and assessment processes to ensure selection of high-quality award holders and research providers", "Organise advisory group meetings including all practical arrangements, preparing supporting paper work and taking minutes", "Organise events, such as seminars, learning events", "Input and manage data on the organisation wide systems and databases and act as a source of information.", "Identify areas for improvement and drive the development of existing knowledge and information systems especially relevant to awards and project management."]	["An MB. Ch. B. or its equivalent", "Master’s Degree in a health science discipline", "A fellowship in a relevant discipline will be added advantage", "A minimum of 6 years of experience in clinical research management."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accur':25C 'adher':34C 'arrang':8C 'clinic':36C 'commiss':10C 'contribut':29C 'deliveri':18C 'dissemin':20C 'document':27C 'grant':12C 'heart':6B 'institut':7B 'maintain':24C 'manag':13C 'medic':2A 'monitor':32C 'offic':4A 'process':14C 'research':3A,9C,22C,26C,37C,41C 'senior':1A 'standard':38C 'support':16C 'team':42C 'uganda':5B 'within':39C	2026-10-25 07:30:04.373337+00	2026-10-25 07:30:04.373337+00	1	UHI 3 MED 1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Principal Medical Research and Training
12	Epidemiologist	epidemiologist-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	4	\N	\N	UGX	To support the implementation of policies and plans on epidemic and disaster preparedness and control by carrying out investigative and analytical epidemiologic activities related to the surveillance, detection, and prevention of the cardiac related diseases.	["Conduct Investigations and respond to disease epidemics", "Participate in surveillance activities and disseminate epidemiologic findings.", "Participate in the epidemiologic studies and urgent outbreak investigations.", "Performs statistical analyses of investigations.", "Participate in the design, management, and use of surveillance systems.", "Supervise data collection, entry, analysis and interpretation of epidemic prone diseases.", "Participate in the design of instruments for the collection of surveillance information and data.", "Training teams on epidemic preparedness, control and surveillance", "Implement new surveillance systems."]	["MBChB or a Degree in Epidemiology or any other related field from a recognized University/Institution.", "Master’s degree with a focus in epidemiology or any other related field will be an added advantage.", "Two (2) years of relevant working experience in epidemiology in a public health organization at national level or multinational Organization."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'activ':27C 'analyt':25C 'cardiac':37C 'carri':21C 'control':19C 'detect':32C 'disast':16C 'diseas':39C 'epidem':14C 'epidemiolog':26C 'epidemiologist':1A 'heart':3B 'implement':8C 'institut':4B 'investig':23C 'plan':12C 'polici':10C 'prepared':17C 'prevent':34C 'relat':28C,38C 'support':6C 'surveil':31C 'uganda':2B	2026-10-25 07:30:04.380698+00	2026-10-25 07:30:04.380698+00	1	UHI 4 MED-1	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Epidemiologist
13	Nursing Officer	nursing-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	4	\N	\N	UGX	To provide safe, comprehensive, and patient-centered cardiac nursing care to individuals with cardiovascular conditions, through assessment, monitoring, treatment, health education, disease prevention, rehabilitation, and continuity of care, in collaboration with the multidisciplinary healthcare team.	["Perform administrative duties at ward/ unit level", "Ensure that quality nursing care is achieved by implementing nursing protocols", "Ensure the smooth running of wards/units by allocating duties to nursing staff and students", "Ensure that wards/units are adequately equipped with equipment, supplies and drugs and ensure their safe custody.", "Provides educational and counseling services to staff, and patient attendants.", "Carries out on-job teaching of midwifery, medical and nursing students.", "Participate in research and community education activities", "Ensures strict adherence to ethical practice by self and the health care team.", "Provide support supervision to staff on the unit.", "Conduct performance Appraise of staff"]	["A Bachelor’s degree in Nursing from a recognized University", "Must be registered with the Uganda Nurses and Midwives Council.", "Must have a valid practicing License."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'assess':23C 'cardiac':14C 'cardiovascular':20C 'care':16C,34C 'center':13C 'collabor':36C 'comprehens':9C 'condit':21C 'continu':32C 'diseas':28C 'educ':27C 'health':26C 'healthcar':40C 'heart':4B 'individu':18C 'institut':5B 'monitor':24C 'multidisciplinari':39C 'nurs':1A,15C 'offic':2A 'patient':12C 'patient-cent':11C 'prevent':29C 'provid':7C 'rehabilit':30C 'safe':8C 'team':41C 'treatment':25C 'uganda':3B	2026-10-25 07:30:04.388255+00	2026-10-25 07:30:04.388255+00	44	UHI 4 MED-2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Nursing Officer – Cardiovascular
14	Cardiac Critical Care Orderlies	cardiac-critical-care-orderlies-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	entry	4	\N	\N	UGX	To provide supportive, safe, and compassionate patient care to cardiac patients, under the supervision of nursing and medical staff, by assisting with patient mobility, hygiene, comfort, transportation, basic observations, and maintenance of a clean and safe care environment.	["Perform cleaning duties.", "Keep wards/units in order", "Transport patients for investigations", "Send orders to stores/picking orders", "Take samples to the laboratories", "Maintain sterility in the unit", "Clean and maintain instruments", "Take and pick linen and instruments to and from the sterilization unit", "Pack linen and swabs."]	["O. Level certificate.", "Training in any health-related course is added advantage"]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'assist':28C 'basic':35C 'cardiac':1A,17C 'care':3A,15C,44C 'clean':41C 'comfort':33C 'compassion':13C 'critic':2A 'environ':45C 'heart':6B 'hygien':32C 'institut':7B 'mainten':38C 'medic':25C 'mobil':31C 'nurs':23C 'observ':36C 'order':4A 'patient':14C,18C,30C 'provid':9C 'safe':11C,43C 'staff':26C 'supervis':21C 'support':10C 'transport':34C 'uganda':5B	2026-10-25 07:30:04.395907+00	2026-10-25 07:30:04.395907+00	3	UHI 8 MED 2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Nursing Officer
15	Theatre Attendant	theatre-attendant-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	entry	4	\N	\N	UGX	Prepare operating rooms, maintain sterility and assist with patient care in the cardiac theatre.	["Prepare Operating Rooms: Set up operating rooms with necessary equipment and supplies, ensuring a sterile environment for surgical procedures.", "Maintain Sterility: Adhere to strict infection prevention control protocols, sterilize equipment, and maintain a clean environment", "Manage equipment: maintain cleanness of surgical equipment and ensure equipment is working prior to use.", "Patient care: Assist with patient positioning, transport and preparation for surgery, ensuring their safety and comfort.", "Inventory Management: Monitor and restock surgical supplies and equipment.", "Documentation: Maintain accurate records of equipment and linen usage, sterilization and inventory.", "CSSD: Assist with handling of used instruments and sets at end of surgery and dispatch to CSSD and picking sterile ones from CSSD to operating room.", "Maintain a safe and comfortable environment."]	["Must have at least O. Level certificate (UCE qualifications)", "A certificate in a relevant health field"]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'assist':12C 'attend':2A 'cardiac':18C 'care':15C 'heart':4B 'institut':5B 'maintain':9C 'oper':7C 'patient':14C 'prepar':6C 'room':8C 'steril':10C 'theatr':1A,19C 'uganda':3B	2026-10-25 07:30:04.403672+00	2026-10-25 07:30:04.403672+00	2	UHI 8 MED 2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Theatre cardiac Nursing Officer
16	Senior Cardiac Public Health Officer	senior-cardiac-public-health-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	4	\N	\N	UGX	To implement cardiac public health programs, ensuring adherence to set standards and guidelines.	["Plan and implement cardiac health promotion and disease prevention programs.", "Facilitate training sessions for healthcare workers and community health promoters on cardiovascular health.", "Conduct periodic assessments to identify gaps in cardiac public health interventions.", "Collect and analyze data to support decision-making and program improvement.", "Collaborate with community leaders to create awareness and improve access to cardiac health services.", "Support the development of communication materials for public health campaigns.", "Conduct field visits to monitor and evaluate ongoing public health activities.", "Assist in preparing quarterly and annual reports on program performance and achievements."]	["A Bachelor’s degree in Medicine, Public Health, Nursing Science, physiotherapy, Nutrition or a related field from a recognized institution.", "A master’s degree in Public Health or related field", "At least three (3) years of working experience as a Cardiac Public Health Officer."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'adher':16C 'cardiac':2A,11C 'ensur':15C 'guidelin':21C 'health':4A,13C 'heart':7B 'implement':10C 'institut':8B 'offic':5A 'program':14C 'public':3A,12C 'senior':1A 'set':18C 'standard':19C 'uganda':6B	2026-10-25 07:30:04.410848+00	2026-10-25 07:30:04.410848+00	1	UHI 3 MED-2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Principal Cardiac Public Health Officer
17	Nutritionist (Dietician)	nutritionist-dietician-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	4	\N	\N	UGX	To provide Nutrition services and guidance to patients and the Institute.	["Evaluate patients’ nutritional needs in relationship to their medical conditions, their nutrient requirements while relating it with their medication.", "Sensitize patients and clients especially in Out Patient department (OPD) in the area of Nutrition and CVDs (Prevention and Management)", "Discuss the nutrition and eating habits with the patients admitted that may be helpful in their treatment and management", "Adjust dietary plans as required depending on the prognosis and as per the clinician recommendations while working with the senior Clinical Nutritionist.", "Discuss, and consult with Principal Clinical Nutritionist and Senior Clinical Nutritionist on how to best manage a patient nutritionally", "Screen and assess patients for the nutritional risks and needs (anthropometry, Clinical, Dietary, and Biomedical assessment)", "Attend to consultations from outpatients regarding their cardiac nutrition requirements in liaison with Senior Clinical Nutritionist.", "Conduct outreaches wherever scheduled and called upon to sensitize the public about using nutrition to prevent CVDs", "Perform any other duties as may be required by supervisor"]	["A bachelor of Science Degree in Human Nutrition and Dietetics or Human Nutrition or Dietetics or Clinical Nutrition, or Food Science and Nutrition or Nutritional Sciences from a recognized University/ College/ Institute", "OR a bachelor’s degree in Food science and Technology or Food Processing Technology", "One (1) year of experience working within a hospital setting or any other health care provider."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'dietician':2A 'guidanc':11C 'heart':4B 'institut':5B,16C 'nutrit':8C 'nutritionist':1A 'patient':13C 'provid':7C 'servic':9C 'uganda':3B	2026-10-25 07:30:04.417914+00	2026-10-25 07:30:04.417914+00	1	UHI 4 MED-2	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Clinical Nutritionist
18	Senior Assistant Secretary	senior-assistant-secretary-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	16	\N	\N	UGX	To provide day-to-day administrative services for the effective interpretation, review and implementation of government policies.	["Take Minutes for Meetings", "Participate in managing Protocol affairs", "Provide administrative support to the Institute", "Ensure the maintenance of assets and facilities", "Ensure the availability, proper use and maintenance of utilities", "Participate in the organization of the national functions", "Appraise and supervise subordinate staff."]	["An Honors Bachelor’s Degree in Arts, Social Sciences, Development Studies, Social Work and Social Administration, Management Science, Law, Commerce (Management option), Business Administration (Management option) or a related field from a recognized awarding Institution.", "Administrative Officer’s Law Course Certificate", "A Post Graduate Diploma in Public Administration, Management, Development Administration or a related field from a recognized awarding Institution.", "At least three (3) years of working experience at the level of Assistant Secretary or equivalent level of experience in administration gained in government or from a reputable organization."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'administr':13C 'assist':2A 'day':10C,12C 'day-to-day':9C 'effect':17C 'govern':23C 'heart':5B 'implement':21C 'institut':6B 'interpret':18C 'polici':24C 'provid':8C 'review':19C 'secretari':3A 'senior':1A 'servic':14C 'uganda':4B	2026-10-25 07:30:04.425536+00	2026-10-25 07:30:04.425536+00	1	UHI 3LWR	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Principal Assistant Secretary
19	Senior Personal Secretary	senior-personal-secretary-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	senior	16	\N	\N	UGX	Support the Chief Executive with high-level secretarial, administrative, and office management tasks and operate with discretion and professionalism.	["In conjunction with relevant officers, drawing up and monitoring appointments and programmes", "Take dictation, transcribing and presenting accurate and error free work", "Attend to callers, either in person or on telephone", "Ensure timely responses to inquiries and correspondences to and from the Office", "Receive incoming mail and supervising the dispatch of outgoing mail", "Organize meetings, taking minutes and conveying decisions of such meetings to the relevant Officers/Offices", "Ensure that relevant documents for meetings and speeches are produced on time and properly organized", "Draft letters of routine nature", "Ensure cleanliness and orderliness of the office", "Manage records in accordance with established security and records management procedures", "Requisition and Manage office stationery and equipment", "Supervise the Secretarial and support personnel for the office", "Conduct background research on various topics to assist in decision-making and report preparation.", "Handle sensitive information and confidential matters with absolute discretion.", "Assist with special projects, tracking progress, and monitoring deadlines."]	["An Honours Bachelor’s degree in Secretarial Studies or equivalent qualifications from a recognized awarding Institution", "A minimum of three (3) years working experience as Personal Secretary in Government or equivalent level of experience gained from a reputable organization or institution."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'administr':16C 'chief':9C 'discret':24C 'execut':10C 'heart':5B 'high':13C 'high-level':12C 'institut':6B 'level':14C 'manag':19C 'offic':18C 'oper':22C 'person':2A 'profession':26C 'secretari':3A,15C 'senior':1A 'support':7C 'task':20C 'uganda':4B	2026-10-25 07:30:04.432597+00	2026-10-25 07:30:04.432597+00	1	UHI 3LWR	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Principal Assistant Secretary
20	Internal Auditor	internal-auditor-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	3	\N	\N	UGX	To conduct routine Internal Audit engagements in accordance with existing regulations and guidelines.	["Examine correctness of payment requests, completeness of documentation and certify requisition or, transactions for further processing.", "Verify receipts, match and undertake on-line reconciliation of invoices and Local Purchase Orders for goods and services procured prior to effecting payments.", "Compile accountability returns, verify and retire advance ledgers.", "Maintain primary financial records and up-to-date books of account.", "Prepare periodic reconciliations of financial statements and carry out monthly cash book reconciliations to bank statements.", "Verify payroll requests and report to ensure correctness of computations, payments and deductions; certify and follow-up approval and payment to beneficiaries."]	["An Honours Bachelor degree in Finance and Accounting or An Honours Bachelor’s degree with a bias in Accountancy or Audit option obtained from a recognized awarding Institution", "Full professional qualification in Accountancy or Audit obtained from a recognized awarding Institution accredited by the Institute of Certified Public Accountants of Uganda (ICPAU)."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accord':13C 'audit':10C 'auditor':2A 'conduct':7C 'engag':11C 'exist':15C 'guidelin':18C 'heart':4B 'institut':5B 'intern':1A,9C 'regul':16C 'routin':8C 'uganda':3B	2026-10-25 07:30:04.43947+00	2026-10-25 07:30:04.43947+00	1	UHI 4UP	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Internal Auditor
21	Laundry Officer	laundry-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	16	\N	\N	UGX	To coordinate the laundry services at the Institute.	["Supervise general flow of activities in laundry.", "Plan laundry activities in line with hospital objectives.", "Take part in the procurement of laundry consumables.", "Ensure laundry consumables are available all the time.", "Ensures enough linen is always available ready to be used.", "Guides and trains laundry staff on better laundry practices.", "Maintains laundry registers (Dispatch, Machine maintenance and Consumables records).", "Ensures proper discipline among laundry staff."]	["Bachelor’s degree in any of humanities.", "Certificate in laundry practice or infection control practice", "Experience in a hospital setting will be added advantage"]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'coordin':7C 'heart':4B 'institut':5B,13C 'laundri':1A,9C 'offic':2A 'servic':10C 'uganda':3B	2026-10-25 07:30:04.446183+00	2026-10-25 07:30:04.446183+00	1	UHI 4 LWR	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Manager – Administration
22	Assistant Inventory Management Officer	assistant-inventory-management-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	18	\N	\N	UGX	To receive, store, issue, and maintain accurate records of medical supplies, equipment, and other institutional stores, ensuring their proper storage, availability, accountability, and timely distribution to authorized users in accordance with hospital policies and procedures.	["Receive, keep, retrieve and issue stores in accordance with the established procedures.", "Receive and compile of requisition orders.", "Verify invoices against goods received notes.", "Post and maintain stores records.", "Undertake stock-taking and stock-inspection."]	["A Diploma in Stores/Supplies Chain Management or Procurement or equivalent qualification from a recognized Institution."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'accord':37C 'account':29C 'accur':14C 'assist':1A 'author':34C 'avail':28C 'distribut':32C 'ensur':24C 'equip':19C 'heart':6B 'hospit':39C 'institut':7B,22C 'inventori':2A 'issu':11C 'maintain':13C 'manag':3A 'medic':17C 'offic':4A 'polici':40C 'procedur':42C 'proper':26C 'receiv':9C 'record':15C 'storag':27C 'store':10C,23C 'suppli':18C 'time':31C 'uganda':5B 'user':35C	2026-10-25 07:30:04.454781+00	2026-10-25 07:30:04.454781+00	1	UHI 5UP	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Inventory Management Officer
23	Biomedical Technician	biomedical-technician-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	2	\N	\N	UGX	Carry out inventory, preventive maintenance, repair and routine service of medical and biomedical equipment.	["Carry out inventory of Medical Equipment.", "Carry out preventive maintenance.", "Repair of medical equipment.", "Plan and budget for repairs", "Carry out end user training", "Carry out routine service of biomedical equipment", "Draft status reports on biomedical equipment."]	["A diploma in Biomedical Technology from a recognized Institution"]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'biomed':1A,18C 'carri':6C 'equip':19C 'heart':4B 'institut':5B 'inventori':8C 'mainten':10C 'medic':16C 'prevent':9C 'repair':11C 'routin':13C 'servic':14C 'technician':2A 'uganda':3B	2026-10-25 07:30:04.461939+00	2026-10-25 07:30:04.461939+00	1	UHI 5SC	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Biomedical Technician
24	Legal Officer	legal-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	20	\N	\N	UGX	The Legal Officer shall provide legal support and advisory services to ensure that the Institute operates within the law.	["Provide legal advice and support on all matters relating to the Institute’s operations.", "Interpret and apply laws, rulings, and regulations applicable in Uganda.", "Ensure that all contracts and agreements are legally sound and align with the Institute’s interests.", "Ensure the organization complies with statutory obligations (e.g., URSB, URA, NSSF, UIA, etc.).", "Keep the organization updated with changes in Ugandan laws and regulations.", "Guide the formulation and review of internal policies and procedures to ensure legal compliance.", "Conduct legal research and prepare legal opinions, reports, and briefs.", "Support corporate governance practices of the organization in line with applicable regulations, standards and laws.", "Maintain and manage legal records, contracts, and statutory documents.", "Conduct training and sensitization on legal issues for staff, especially around labor laws, ethics, and compliance."]	["Bachelor’s degree in Law (LLB) from a recognized university.", "Diploma in Legal Practice from the Law Development Centre (LDC), Uganda."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'advisori':14C 'ensur':17C 'heart':4B 'institut':5B,20C 'law':24C 'legal':1A,7C,11C 'offic':2A,8C 'oper':21C 'provid':10C 'servic':15C 'shall':9C 'support':12C 'uganda':3B 'within':22C	2026-10-25 07:30:04.469915+00	2026-10-25 07:30:04.469915+00	1	UHI 4 LEG	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Legal Officer
25	Assistant Engineering Officer	assistant-engineering-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	23	\N	\N	UGX	Responsible for maintenance and repairing various facilities to enable optimal functioning and safety and contributing to the smooth operation of the hospital’s infrastructure.	["Identify and troubleshoot equipment malfunctions, utilizing technical knowledge and analytical skills to resolve issues.", "Maintain accurate records of equipment maintenance, repairs, and inspections.", "Conduct safety inspections to promote compliance with relevant safety regulations.", "Coordinate maintenance activities, share information, and collaborate with other departments and staff.", "Participate in training programs for equipment users and technicians."]	["A Diploma in civil engineering from a recognized institution.", "Experience in civil engineering will be added advantage."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'assist':1A 'contribut':21C 'enabl':15C 'engin':2A 'facil':13C 'function':17C 'heart':5B 'hospit':28C 'infrastructur':30C 'institut':6B 'mainten':9C 'offic':3A 'oper':25C 'optim':16C 'repair':11C 'respons':7C 'safeti':19C 'smooth':24C 'uganda':4B 'various':12C	2026-10-25 07:30:04.477439+00	2026-10-25 07:30:04.477439+00	1	UHI 5SC	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Civil Engineer
26	Assistant Security Officer	assistant-security-officer-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	mid	21	\N	\N	UGX	To support maintenance of a safe and secure environment for patients, staff, clients, property, and hospital assets by implementing security procedures, monitoring access and activities, responding to security incidents, and reporting security concerns in accordance with institutional policies and procedures.	["Assist the Head of Security in Management of the Security at the Institute", "In charge of day-to-day running of security matters in the Hospital", "Participate in planning, monitoring and evaluation of security matters in the Unit", "Ensure safety of Hospital properties, vehicle and estates", "Prepare security reports.", "Manage and account for allocated resources"]	["A Diploma in any field from recognised institution.", "Must have had police training or training in security discipline from a recognised institution.", "A minimum of three (3) years of experience in a reputable organisation as security personnel."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'access':29C 'accord':41C 'activ':31C 'asset':23C 'assist':1A 'client':19C 'concern':39C 'environ':15C 'heart':5B 'hospit':22C 'implement':25C 'incid':35C 'institut':6B,43C 'mainten':9C 'monitor':28C 'offic':3A 'patient':17C 'polici':44C 'procedur':27C,46C 'properti':20C 'report':37C 'respond':32C 'safe':12C 'secur':2A,14C,26C,34C,38C 'staff':18C 'support':8C 'uganda':4B	2026-10-25 07:30:04.484454+00	2026-10-25 07:30:04.484454+00	1	UHI 6LWR	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Senior Security Officer
27	Receptionist	receptionist-uganda-heart-institute	Uganda Heart Institute	Kampala	f	full-time	entry	16	\N	\N	UGX	Shall be the first point of contact for patients and visitors and shall handle basic administrative tasks and front desk tasks in the Institute.	["Oversee the management of the front desk office and reception area in accordance with established standards.", "Collaborate with the clinical team to provide guidance to patients and direct them to appropriate service points.", "Efficiently handle incoming and outgoing phone calls, maintaining comprehensive call records as per Hospital guidelines", "Welcome, register, and assist patients and visitors, ensuring they are directed to relevant offices.", "Address inquiries and offer general information regarding the department’s activities and services", "Disseminate information about the Hospital’s services, complying with established Hospital policies and procedures.", "Foster effective coordination between internal and external customers and various Departments."]	["Uganda Certificate of Education (UCE) with at least a credit in English", "Certificate in Customer Care, Public Relations or any other related training is required."]	{}	https://www.uhi.go.ug	erecruitment@uhi.go.ug	published	2026-10-25 07:30:04+00	2026-11-11 20:59:59+00	\N	'administr':20C 'basic':19C 'contact':11C 'desk':24C 'first':8C 'front':23C 'handl':18C 'heart':3B 'institut':4B,28C 'patient':13C 'point':9C 'receptionist':1A 'shall':5C,17C 'task':21C,25C 'uganda':2B 'visitor':15C	2026-10-25 07:30:04.491384+00	2026-10-25 07:30:04.491384+00	2	UHI 7 LWR	Eligible persons should address their applications including a cover letter, copies of their academic/professional certificates and transcripts, certificates of registration and valid practicing licenses where applicable, curriculum vitae (CV), O. Level Certificates, A. level certificates (where applicable), copy of the National Identity Card and evidence of work experience where required, to the Executive Director, Uganda Heart Institute, P.O. Box 37392, Kampala. Applications can also be hand delivered to Uganda Heart Institute Headquarters, Mulago – Kampala. Online applications should be sent on the UHI official recruitment email erecruitment@uhi.go.ug. Applications which will be submitted or emailed without complete attachments or any applications which will be sent on any other email addresses other than one mentioned above, will not be accepted. Applications both physical and online, must be received not later than 5:00 pm on 11th November 2026.	Communication Officer
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (key, failure_count, locked_until, window_started_at, updated_at) FROM stdin;
subscribe:ip:::1	1	\N	2026-10-20 12:59:41.255013+00	2026-10-20 12:59:41.255013+00
login:email:12f9e032ab9f26c107f3fee39bc812b658291748a45e10469d21fc77630ec0a6	1	\N	2026-10-25 06:39:06.188228+00	2026-10-25 06:39:06.188228+00
login:email:258d8dc916db8cea2cafb6c3cd0cb0246efe061421dbd83ec3a350428cabda4f	3	\N	2026-10-25 06:39:09.674109+00	2026-10-25 06:49:55.018643+00
\.


--
-- Data for Name: newsletter_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.newsletter_deliveries (id, newsletter_id, subscriber_id, status, attempts, last_error, next_attempt_at, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: newsletters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.newsletters (id, subject, preheader, body_html, body_text, status, scheduled_at, sent_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version, applied_at) FROM stdin;
0001_common_functions	2026-10-20 09:24:14.462224+00
0002_admin_users	2026-10-20 09:24:14.469404+00
0003_sessions	2026-10-20 09:24:14.482796+00
0004_job_categories	2026-10-20 09:24:14.491415+00
0005_jobs	2026-10-20 09:24:14.502208+00
0006_job_status_history	2026-10-20 09:24:14.52065+00
0007_social_profiles	2026-10-20 09:24:14.531678+00
0008_subscribers	2026-10-20 09:24:14.540603+00
0009_newsletters	2026-10-20 09:24:14.553785+00
0010_newsletter_deliveries	2026-10-20 09:24:14.563974+00
0011_settings	2026-10-20 09:24:14.577014+00
0012_site_assets	2026-10-20 09:24:14.584201+00
0013_smtp_settings	2026-10-20 09:24:14.591096+00
0014_audit_logs	2026-10-20 09:24:14.598532+00
0015_login_attempts	2026-10-20 09:24:14.609039+00
0016_contact_settings	2026-10-20 12:10:11.557967+00
0017_job_positions_and_salary_scale	2026-10-25 07:00:25.427428+00
0018_job_salary_amount_or_scale	2026-10-25 07:05:29.610692+00
0019_job_application_instructions	2026-10-25 07:10:27.737745+00
0020_job_reports_to	2026-10-25 07:30:03.723551+00
0021_analytics_events	2026-10-27 08:27:16.972793+00
0022_analytics_daily	2026-10-27 08:27:17.005799+00
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, payload, last_activity) FROM stdin;
6a8e30a4d3ba016a0ada8c43a1268bce887c97b8db60f7bc5c671e67f28c539d	{"_flash_old":[],"_touched":1793095205,"admin_id":6,"admin_session_version":1,"admin_last_seen":1793090904}	2026-10-27 10:00:05.667538+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (key, value, updated_at) FROM stdin;
site_name	"KaziUG"	2026-10-20 12:24:31.33981+00
tagline	"Jobs in Uganda"	2026-10-20 12:24:31.33981+00
contact_email	"markbrightbaraka@gmail.com"	2026-10-20 12:24:31.33981+00
physical_address	""	2026-10-20 12:24:31.33981+00
footer_text	"Find jobs across Kampala, Entebbe, Jinja, Mbarara, Gulu and beyond."	2026-10-20 12:24:31.33981+00
jobs_per_page	8	2026-10-20 12:24:31.33981+00
meta_description	"Find jobs in Uganda across Kampala, Entebbe, Jinja, Mbarara, Gulu, Kasese and remote roles."	2026-10-20 12:24:31.33981+00
maintenance_mode	false	2026-10-20 12:24:31.33981+00
whatsapp_number	"256773034311"	2026-10-20 12:24:31.33981+00
cv_service_price	100000	2026-10-20 12:24:31.33981+00
\.


--
-- Data for Name: site_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_assets (key, mime_type, content, updated_at) FROM stdin;
\.


--
-- Data for Name: smtp_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smtp_settings (id, host, port, encryption, username, password_encrypted, from_name, from_email, reply_to, last_tested_at, last_test_result, updated_at) FROM stdin;
1	127.0.0.1	1025	none		\N	KaziUG	jobs@kaziug.local		2026-10-20 10:03:25.820821+00	OK: test email sent to owner@example.org.	2026-10-20 10:03:25.820821+00
\.


--
-- Data for Name: social_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_profiles (id, platform, label, url, icon_key, sort_order, is_visible, created_at, updated_at) FROM stdin;
2	X	KaziUG on X	https://x.com/example	x	20	t	2026-10-20 09:57:08.318953+00	2026-10-20 09:57:08.318953+00
4	Instagram	KaziUG on Instagram	https://www.instagram.com/example	instagram	40	t	2026-10-20 09:57:08.41223+00	2026-10-20 09:57:08.41223+00
5	WhatsApp	KaziUG WhatsApp channel	https://whatsapp.com/channel/example	whatsapp	50	t	2026-10-20 09:57:08.430649+00	2026-10-20 09:57:08.430649+00
1	Facebook	KaziUG on Facebook	https://www.facebook.com/kaziuganda	facebook	10	t	2026-10-20 09:57:08.288454+00	2026-10-23 11:13:20.031941+00
3	LinkedIn	KaziUG on LinkedIn	https://www.linkedin.com/company/kaziug/	linkedin	30	t	2026-10-20 09:57:08.374107+00	2026-10-25 06:50:50.459602+00
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscribers (id, email, name, status, consent_at, consent_ip, confirm_token_hash, confirm_sent_at, confirmed_at, unsubscribe_token, created_at, unsubscribed_at) FROM stdin;
2	markbrightbaraka22@gmail.com	Mark Bright Baraka	pending	2026-10-20 12:59:41.262059+00	::1	d769e643e13455bb5522f178cab6b4b6dfaaeeae86caedebb58c92629554420d	2026-10-20 12:59:41.262059+00	\N	99o0jpw38ZHsOcanqa4A21IV0A_svGp5VMDbpvssCBo	2026-10-20 12:59:41.262059+00	\N
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 6, true);


--
-- Name: analytics_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analytics_events_id_seq', 12, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 46, true);


--
-- Name: job_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_categories_id_seq', 23, true);


--
-- Name: job_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_status_history_id_seq', 27, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 27, true);


--
-- Name: newsletter_deliveries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.newsletter_deliveries_id_seq', 1, true);


--
-- Name: newsletters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.newsletters_id_seq', 1, true);


--
-- Name: social_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_profiles_id_seq', 5, true);


--
-- Name: subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscribers_id_seq', 2, true);


--
-- Name: admin_users admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_email_key UNIQUE (email);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_singleton_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_singleton_key UNIQUE (singleton);


--
-- Name: analytics_daily analytics_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily
    ADD CONSTRAINT analytics_daily_pkey PRIMARY KEY (day, dimension, key);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: analytics_salts analytics_salts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_salts
    ADD CONSTRAINT analytics_salts_pkey PRIMARY KEY (day);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: job_categories job_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_categories
    ADD CONSTRAINT job_categories_pkey PRIMARY KEY (id);


--
-- Name: job_categories job_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_categories
    ADD CONSTRAINT job_categories_slug_key UNIQUE (slug);


--
-- Name: job_status_history job_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_status_history
    ADD CONSTRAINT job_status_history_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_slug_key UNIQUE (slug);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (key);


--
-- Name: newsletter_deliveries newsletter_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_deliveries
    ADD CONSTRAINT newsletter_deliveries_pkey PRIMARY KEY (id);


--
-- Name: newsletter_deliveries newsletter_deliveries_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_deliveries
    ADD CONSTRAINT newsletter_deliveries_unique UNIQUE (newsletter_id, subscriber_id);


--
-- Name: newsletters newsletters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: site_assets site_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_assets
    ADD CONSTRAINT site_assets_pkey PRIMARY KEY (key);


--
-- Name: smtp_settings smtp_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smtp_settings
    ADD CONSTRAINT smtp_settings_pkey PRIMARY KEY (id);


--
-- Name: social_profiles social_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_profiles
    ADD CONSTRAINT social_profiles_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_unsubscribe_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_unsubscribe_token_key UNIQUE (unsubscribe_token);


--
-- Name: analytics_daily_dimension_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX analytics_daily_dimension_day_idx ON public.analytics_daily USING btree (dimension, day);


--
-- Name: analytics_events_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX analytics_events_category_id_idx ON public.analytics_events USING btree (category_id);


--
-- Name: analytics_events_job_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX analytics_events_job_id_idx ON public.analytics_events USING btree (job_id);


--
-- Name: analytics_events_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX analytics_events_occurred_at_idx ON public.analytics_events USING btree (occurred_at);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at DESC);


--
-- Name: audit_logs_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_idx ON public.audit_logs USING btree (entity, entity_id);


--
-- Name: job_categories_sort_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_categories_sort_idx ON public.job_categories USING btree (sort_order, name);


--
-- Name: job_status_history_changed_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_status_history_changed_by_idx ON public.job_status_history USING btree (changed_by);


--
-- Name: job_status_history_job_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_status_history_job_idx ON public.job_status_history USING btree (job_id, changed_at DESC);


--
-- Name: jobs_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_category_id_idx ON public.jobs USING btree (category_id);


--
-- Name: jobs_published_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_published_at_idx ON public.jobs USING btree (published_at DESC);


--
-- Name: jobs_salary_min_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_salary_min_idx ON public.jobs USING btree (salary_min) WHERE (deleted_at IS NULL);


--
-- Name: jobs_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_search_idx ON public.jobs USING gin (search);


--
-- Name: jobs_status_published_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_status_published_idx ON public.jobs USING btree (status, published_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: login_attempts_updated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX login_attempts_updated_at_idx ON public.login_attempts USING btree (updated_at);


--
-- Name: newsletter_deliveries_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX newsletter_deliveries_due_idx ON public.newsletter_deliveries USING btree (next_attempt_at) WHERE (status = 'queued'::text);


--
-- Name: newsletter_deliveries_newsletter_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX newsletter_deliveries_newsletter_status_idx ON public.newsletter_deliveries USING btree (newsletter_id, status);


--
-- Name: newsletter_deliveries_subscriber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX newsletter_deliveries_subscriber_idx ON public.newsletter_deliveries USING btree (subscriber_id);


--
-- Name: newsletters_created_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX newsletters_created_by_idx ON public.newsletters USING btree (created_by);


--
-- Name: newsletters_status_scheduled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX newsletters_status_scheduled_idx ON public.newsletters USING btree (status, scheduled_at);


--
-- Name: sessions_last_activity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_idx ON public.sessions USING btree (last_activity);


--
-- Name: social_profiles_sort_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_profiles_sort_idx ON public.social_profiles USING btree (sort_order, id);


--
-- Name: subscribers_confirm_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscribers_confirm_token_hash_key ON public.subscribers USING btree (confirm_token_hash) WHERE (confirm_token_hash IS NOT NULL);


--
-- Name: subscribers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscribers_created_at_idx ON public.subscribers USING btree (created_at DESC);


--
-- Name: subscribers_email_lower_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscribers_email_lower_key ON public.subscribers USING btree (lower(email));


--
-- Name: subscribers_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscribers_status_idx ON public.subscribers USING btree (status);


--
-- Name: admin_users admin_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER admin_users_updated_at BEFORE UPDATE ON public.admin_users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: job_categories job_categories_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER job_categories_updated_at BEFORE UPDATE ON public.job_categories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: jobs jobs_search_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER jobs_search_trg BEFORE INSERT OR UPDATE OF title, company, summary, skills ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.jobs_search_update();


--
-- Name: jobs jobs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER jobs_updated_at BEFORE UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: newsletters newsletters_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER newsletters_updated_at BEFORE UPDATE ON public.newsletters FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: smtp_settings smtp_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER smtp_settings_updated_at BEFORE UPDATE ON public.smtp_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: social_profiles social_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER social_profiles_updated_at BEFORE UPDATE ON public.social_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: analytics_events analytics_events_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.job_categories(id) ON DELETE SET NULL;


--
-- Name: analytics_events analytics_events_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE SET NULL;


--
-- Name: job_status_history job_status_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_status_history
    ADD CONSTRAINT job_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: job_status_history job_status_history_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_status_history
    ADD CONSTRAINT job_status_history_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: jobs jobs_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.job_categories(id) ON DELETE RESTRICT;


--
-- Name: newsletter_deliveries newsletter_deliveries_newsletter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_deliveries
    ADD CONSTRAINT newsletter_deliveries_newsletter_id_fkey FOREIGN KEY (newsletter_id) REFERENCES public.newsletters(id) ON DELETE CASCADE;


--
-- Name: newsletter_deliveries newsletter_deliveries_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_deliveries
    ADD CONSTRAINT newsletter_deliveries_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON DELETE CASCADE;


--
-- Name: newsletters newsletters_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 2AgQ63HPlz22n0sVPmJoRg4HcnD3kO5Y9BHg3HJGcfrANOX5PSEvAYrxfV3sviC

