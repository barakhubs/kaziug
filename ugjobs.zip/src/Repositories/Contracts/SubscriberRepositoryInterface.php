<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Domain\Subscriber;

interface SubscriberRepositoryInterface
{
    public function findById(int $id): ?Subscriber;

    /** Case-insensitive. */
    public function findByEmail(string $email): ?Subscriber;

    /** A pending subscriber whose confirmation email was sent less than $maxAgeSeconds ago. */
    public function findPendingByConfirmHash(string $hash, int $maxAgeSeconds): ?Subscriber;

    public function findByUnsubscribeToken(string $token): ?Subscriber;

    /** New pending subscriber with consent recorded now. */
    public function createPending(string $email, ?string $name, string $consentIp, string $confirmHash, string $unsubscribeToken): Subscriber;

    /** Back to pending with fresh consent and a new confirmation token (re-subscribe or resend). */
    public function restartConfirmation(int $id, ?string $name, string $consentIp, string $confirmHash): void;

    public function activate(int $id): void;

    public function unsubscribe(int $id): void;

    public function delete(int $id): void;

    public const SORTS = ['email', 'status', 'joined'];

    /**
     * @param array{q?: string, status?: string} $filters
     * @param string $sort one of self::SORTS
     * @return array{items: list<Subscriber>, total: int}
     */
    public function search(array $filters, int $limit, int $offset, string $sort = 'joined', string $direction = 'desc'): array;

    /** @return array<string, int> */
    public function countByStatus(): array;

    /**
     * Sign-ups through the website (imports excluded), confirmations of those, and unsubscribes,
     * each counted by when it happened, between $from (inclusive) and $to (exclusive).
     * @return array{signups: int, confirmations: int, unsubscribes: int}
     */
    public function activityBetween(\DateTimeImmutable $from, \DateTimeImmutable $to): array;

    /** @return iterable<Subscriber> */
    public function each(?string $status): iterable;

    /**
     * @param list<string> $emails lower-case
     * @return list<string> those already present (lower-case)
     */
    public function existingEmails(array $emails): array;

    /**
     * Inserts active subscribers whose consent was given elsewhere; existing emails are skipped.
     * @param list<array{email: string, name: ?string, unsubscribe_token: string}> $rows
     * @return int rows inserted
     */
    public function insertImported(array $rows): int;
}
